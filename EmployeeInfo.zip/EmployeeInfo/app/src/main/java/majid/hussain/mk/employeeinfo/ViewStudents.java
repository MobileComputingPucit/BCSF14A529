package majid.hussain.mk.employeeinfo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class ViewStudents extends AppCompatActivity {

    private ListView listView;
    private ArrayAdapter<students> adapter;
    students st = new students();

    private ArrayList<students> listAll;
    //private List<students> itemsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_students);

        listView = (ListView) findViewById(R.id.listView);

        List<students> list = students.listAll(students.class);
        listAll=(ArrayList<students>) students.listAll(students.class);
        adapter = new ArrayAdapter<students>(ViewStudents.this,android.R.layout.simple_list_item_1, listAll);

        listView.setAdapter(adapter);

        Toast.makeText(this,""+list,Toast.LENGTH_LONG).show();
    }
}
