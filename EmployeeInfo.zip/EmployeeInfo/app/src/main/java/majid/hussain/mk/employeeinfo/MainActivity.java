package majid.hussain.mk.employeeinfo;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    Context context;

    Snackbar sb;

    boolean BackPressed = false;

    private EditText StudentName;
    private EditText FatherName;
    private EditText ContactNo;
    private EditText EmailAddress;
    private EditText Age;
    private Button SaveStudent;

    private ListView listView;
    private ArrayAdapter<students> adapter;
    //students student = new students();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = this;

        StudentName = (EditText) findViewById(R.id.StudentName);
        FatherName = (EditText) findViewById(R.id.FatherName);
        ContactNo = (EditText) findViewById(R.id.ContactNo);
        EmailAddress = (EditText) findViewById(R.id.EmailAddress);
        Age = (EditText) findViewById(R.id.Age);
        SaveStudent = (Button) findViewById(R.id.SaveStudent);

        List<students> list = students.listAll(students.class);

        View.OnClickListener save = new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                if(StudentName.getText().toString().trim().length() != 0 && FatherName.getText().toString().trim().length() !=0 && ContactNo.getText().toString().trim().length() != 0 && EmailAddress.getText().toString().trim().length() !=0 && Age.getText().toString().trim().length() !=0) {

                    students st = new students(StudentName.getText().toString(), FatherName.getText().toString(), ContactNo.getText().toString(), EmailAddress.getText().toString(), Age.getText().toString());
                    //students st = new students("Majid","Hussain","03214148818","majid@gmail.com","22");
                    //students st = new students("Majid");
                    //students st = new students("Khadim");
                    st.save();

                    Toast.makeText(context,"Info Saved!" ,Toast.LENGTH_SHORT).show();
                    clearText();
                }else
                    Toast.makeText(context,"Please enter all fields!" ,Toast.LENGTH_SHORT).show();
            }
        };

        SaveStudent.setOnClickListener(save);

        View.OnClickListener click = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ContextCompat.checkSelfPermission(context,
                        Manifest.permission.READ_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions((Activity) context,
                            new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                            Globals.READ_EXTERNAL);
                }else{

                    Intent ii = new Intent(
                            Intent.ACTION_PICK,
                            android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(ii, Globals.SELECTED_PICTURE);

                }
            }
        };

        findViewById(R.id.buttonLoadPicture).setOnClickListener(click);
        //findViewById(R.id.Add_Company).setOnClickListener(click);

        /*View.OnClickListener img = new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(
                        Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(i, Globals.SELECTED_PICTURE);
            }
        };*/

        //findViewById(R.id.buttonLoadPicture).setOnClickListener(img);

        sb = Snackbar.make(findViewById(R.id.layoutCompany), getResources().getString(R.string.exit_msg), Snackbar.LENGTH_LONG);
        sb.setAction("Exit", new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                BackPressed = true;
                sb.dismiss();
            }
        });

        ActionBar ab = getSupportActionBar();
        ab.setTitle(Html.fromHtml("<font color='white'>Enter</font> <font color='white'><b>StudentInfo</b></font>"));
        //ab.setSubtitle("A small app for saving employee data");

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {

        switch (requestCode) {
            case Globals.READ_EXTERNAL:
                if (grantResults.length > 0) {
                    for (int i = 0; i < grantResults.length; i++) {
                        if (PackageManager.PERMISSION_GRANTED == grantResults[i]) {

                            Intent ii = new Intent(
                                    Intent.ACTION_PICK,
                                    android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                            startActivityForResult(ii, Globals.SELECTED_PICTURE);

                            //Toast.makeText(context, "Permission granted", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(context, R.string.Gallery, Toast.LENGTH_SHORT).show();
                            //onBackPressed();
                        }
                    }
                }
                break;

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == Globals.SELECTED_PICTURE && resultCode == RESULT_OK && null != data) {
            Uri selectedImage = data.getData();
            String[] filePathColumn = {MediaStore.Images.Media.DATA};

            Cursor cursor = getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();

            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();

            ImageView imageView = (ImageView) findViewById(R.id.imgView);
            imageView.setImageBitmap(BitmapFactory.decodeFile(picturePath));

        }

    }

    public void clearText(){
        StudentName.setText("");
        FatherName.setText("");
        ContactNo.setText("");
        EmailAddress.setText("");
        Age.setText("");
    }

}