package majid.hussain.mk.employeeinfo;

import android.content.SharedPreferences;

/**
 * Created by Abdul Majid on 1/23/2018.
 */
public class Globals {

        public static SharedPreferences prefs;

        public static final String URL_TO_DOWNLOAD = "http://unec.edu.az/application/uploads/2014/12/pdf-sample.pdf";
        // Permissions Request Code
        public  static final int WRITE_EXTERNAL = 6788;
        public  static final int WRITE_EXTERNAL_DWLD = 5161;

        public  static final int READ_EXTERNAL = 6789;
        public  static final int READ_EXTERNAL_DWLD = 5162;

        public static final int SELECTED_PICTURE = 1;

        // SHARED PREFERENCES KEYS
        public static final String PREF_FIRST_START="first_start";
        public static final String PREF_FILE_PART_SIZE="file_part_size";

}

