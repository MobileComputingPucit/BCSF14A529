package majid.hussain.mk.employeeinfo;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


public class Main2Activity extends AppCompatActivity implements View.OnClickListener{

    private Button AddStudent;

    private Button ViewStudents;

    private  Button DeleteStudent;

    Snackbar sb;

    boolean BackPressed = false;

    Context ctx;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        AddStudent = (Button) findViewById(R.id.AddStudent);

        AddStudent.setOnClickListener(this);

        ViewStudents = (Button) findViewById(R.id.ViewStudents);

        ViewStudents.setOnClickListener(this);

        DeleteStudent = (Button) findViewById(R.id.DeleteStudent);

        DeleteStudent.setOnClickListener(this);

        ActionBar ab = getSupportActionBar();
        ab.setTitle(Html.fromHtml("<font color='white'>Welcome To</font> <font color='red'><b>StudentInfo</b></font>"));
        ab.setSubtitle("A simple app for saving Student data");

}

    @Override
    public void onBackPressed() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(Main2Activity.this);
        builder.setMessage("Do you want to exit ?");
        builder.setCancelable(true);

        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });

        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    @Override
    public void onClick(View v) {

        if(v == AddStudent){
            Intent intent = new Intent(this , MainActivity.class);
            startActivity(intent);
        }
        else if (v == ViewStudents){
            Intent intent = new Intent(this , ViewStudents.class);
            startActivity(intent);
        }
        else if( v == DeleteStudent){
            Toast.makeText(this,"Couldn't Implement it. Sorry!",Toast.LENGTH_SHORT).show();
        }




    }



}