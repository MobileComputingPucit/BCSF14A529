package majid.hussain.mk.employeeinfo;

import com.orm.SugarRecord;

import java.util.List;

/**
 * Created by Abdul Majid on 1/26/2018.
 */
public class students extends SugarRecord {

    String Name;
    String FatherName;
    String ContactNo;
    String EmailAddress;
    String Age;

    public students()
    {

    }

    public students(String Name , String FatherName , String ContactNo , String EmailAddress , String Age)
    {
        this.Name = Name;
        this.FatherName = FatherName;
        this.ContactNo = ContactNo;
        this.EmailAddress = EmailAddress;
        this.Age = Age;
    }

    public static List<students> read(){
        List<students> lists;

        try {
            lists = students.listAll(students.class);
            return lists;
        }
        catch(Exception e){
            return null;
        }
    }

/*
    public void setName(String Name)
    {
        this.Name = Name;
    }

    public String getName()
    {
        return Name;
    }

    public void setFatherName(String FatherName)
    {
        this.FatherName = FatherName;
    }

    public String getFatherName()
    {
        return FatherName;
    }

    public void setEmailAddress(String EmailAddress)
    {
        this.EmailAddress = EmailAddress;
    }

    public String getEmailAddress()
    {
        return EmailAddress;
    }

    public void setContactNo(String ContactNo)
    {
        this.ContactNo = ContactNo;
    }

    public String getContactNo()
    {
        return ContactNo;
    }

    public void setAge(String Age)
    {
        this.Age = Age;
    }

    public String getAge()
    {
        return Age;
    }*/

}
